<table>
	<tbody>
		<tr>
			<th align="center">Version</th>
			<th align="center">Notes</th>
		</tr>
		<tr>
			<td align="center">1.0.1</td>
			<td align="left">
				<ul>
					<li>Update for patch 0.217.25</li>
					<li>
						Switched to using Jotunn for syncing server data.
						<ul>
							<li>Removed EnableMod setting.</li>
							<li>Removed LockingConfiguration setting.</li>
						</ul>
					</li>
		
					<li>Added a config file watcher to sync changes made on disk.</li>
					<li>Added config setting to control how much information output to the log. Should be useful for user's reporting issues.</li>
				</ul>
			</td>
		</tr>
		<tr>
			<td align="center">1.0.0</td>
			<td align="left">
				<ul>
					<li>Initial release.</li>
				</ul>
			</td>
		</tr>
	</tbody>
</table>

